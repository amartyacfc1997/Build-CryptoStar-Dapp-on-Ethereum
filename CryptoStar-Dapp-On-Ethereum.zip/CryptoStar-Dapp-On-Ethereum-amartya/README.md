# CryptoStar-Dapp-On-Ethereum
Udacity Blockchain Project -  Decentralized Star Notary Service Project

Web3: web3@1.0.0-beta.37  
Truffle v5.0.2  
openzeppelin-solidity v2.1.2  
Token name: "StarToken"  
Token symbol: "STN"  
Contract Address: 0xBEE92Fb49F969b42e2d9df2Ff76821a14a945dc4  

